export const setConstituency=(constituency)=>{
    return {
        type:'setConstituency',
        payload:constituency
    };
};



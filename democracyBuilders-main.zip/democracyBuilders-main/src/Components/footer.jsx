import React from 'react'
export default function Footer()
{
    return <footer style={{ position:'fixed',bottom:'0px',background:'#3f94ee',width:'100%',color:'white',padding:'.5rem',display:'flex',flexDirection:'column',alignItems:'center' }}>
        <h6>all rights reserved</h6>
        <p>for queries:<b> indian_gov@gov.in</b></p>
    </footer>
}
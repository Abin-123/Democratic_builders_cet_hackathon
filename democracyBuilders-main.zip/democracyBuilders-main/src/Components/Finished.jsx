import React from "react";
import { Container,Row,Col } from "react-bootstrap";

const Finished = (props) => {
  
    return (
        <div className="login-container">
            <h1 className="welcome-message">Voting is Finished</h1>
           
        </div>
    )
}

export default Finished;